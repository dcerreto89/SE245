﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Info
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //Get Data
            Cars temp = new Cars();
            //Perform the search we created in Cars class and store the returned dataset
            DataSet ds = temp.SearchCars(txtSearchMake.Text, txtSearchModel.Text);

            //Display data (dataset)
            dgvResults.DataSource = ds;                                  //point datagrid to dataset
            dgvResults.DataMember = ds.Tables["Cars_Temp"].ToString();     // What table in the dataset?
        }

        private void dgvResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //Gather the information (Gathers the row clicked, then chooses the first cell's data
            string strCarID = dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString();


            //Convert the string over to an integer
            int intCarID = Convert.ToInt32(strCarID);


            Form1 Editor = new Form1(intCarID);
            Editor.ShowDialog();
        }
    }
}
