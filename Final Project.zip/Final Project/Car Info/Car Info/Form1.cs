﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Info
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            btnDeleteCar.Visible = false;
            btnUpdateCar.Visible = false;
        }

        // Form that fills in values from search
        public Form1(int intCarID)
        {
            InitializeComponent();  //Creates and init's all form objects
            btnAddCar.Visible = false;

            //Gather info about this one person and store it in a datareader
            Cars temp = new Cars();
            SqlDataReader dr = temp.FindOneCar(intCarID);

            //Use that info to fill out the form
            //Loop thru the records stored in the reader 1 record at a time
            // Note that since this is based on one car's ID, then we
            //  should only have one record
            while (dr.Read())
            {
                //Take the Name(s) from the datareader and copy them
                // into the appropriate text fields
                txtMake.Text = dr["Make"].ToString();
                txtModel.Text = dr["Model"].ToString();
                txtLiters.Text = dr["Liters"].ToString();
                txtCylinders.Text = dr["Cylinders"].ToString();
                txtYear.Text = dr["Year"].ToString();
                
                //We added this one to store the ID in a new label
                lblCarID.Text = dr["CarID"].ToString();
            }
        }

        private void btnAddCar_Click(object sender, EventArgs e)
        {
            // create an instance of cars
            Cars temp = new Cars();

            // fill cars with info from form
            temp.Make = txtMake.Text;
            temp.Model = txtModel.Text;
            temp.Liters = txtLiters.Text;
            temp.Cylinders = txtCylinders.Text;
            temp.Year = txtYear.Text;

            //Look for Errors listed in Feedback...If none found, display data
            if (!temp.Feedback.Contains("ERROR:"))
            {
                //output the results from the cars object
                lblResults.Text = temp.Make + "\n" + temp.Model + "\n" + temp.Liters + "\n" + temp.Cylinders + "\n" + temp.Year;

                //send person info to the database
                lblConnection.Text = temp.addRecord();
            }
            else
            {
                //Else...Display Error Messages
                lblResults.Text = temp.Feedback;
            }
        }

        private void btnDeleteCar_Click(object sender, EventArgs e)
        {
            Int32 intCarID = Convert.ToInt32(lblCarID.Text);  //Get the ID from the Label

            //Create a Car so we can use the delete method
            Cars temp = new Cars();

            //Use the Car ID and pass it to the delete function
            // and get the number of records deleted
            lblConnection.Text = temp.DeleteOneCar(intCarID);
        }

        private void btnUpdateCar_Click(object sender, EventArgs e)
        {
            //create a car object
            Cars temp = new Cars();

            //fill the Cars from the form
            temp.Make = txtMake.Text;
            temp.Model = txtModel.Text;
            temp.Liters = txtLiters.Text;
            temp.Cylinders = txtCylinders.Text;
            temp.Year = txtYear.Text;

            temp.CarID = Convert.ToInt32(lblCarID.Text);

            if (!temp.Feedback.Contains("ERROR:"))
            {
                //update cars info
                lblConnection.Text = temp.UpdateARecord();
            }
            else
            {
                //Else...Display Error Messages
                lblResults.Text = temp.Feedback;
            }
        }
    }
}
