﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab_4;
using System.Data;
using System.Data.SqlClient;

namespace Car_Info
{
    public class Cars
    {
        private string make;
        private string model;
        private string liters;
        private string cylinders;
        private string year;

        private int carID;

        protected string feedback;

        public string Make
        {
            get { return make; }
            set
            {
                if ( Validation.IsItFilledIn(value))
                {
                    make = value;
                }
                else
                {
                    feedback += "\nERROR: Please enter a make.";
                }
                
            }
        }

        public string Model
        {
            get { return model; }
            set
            {
                if ( Validation.IsItFilledIn(value))
                {
                    model = value;
                }
                else
                {
                    feedback += "\nERROR: Please enter a model.";
                }
                
            }
        }

        public string Liters
        {
            get { return liters; }
            set
            {
                if ( Validation.IsDoubleInRange(value, 1.0, 5.0))
                {
                    liters = value;
                }
                else
                {
                    feedback += "\nERROR: Please enter a valid amount of liters.";
                }
                
            }
        }

        public string Cylinders
        {
            get { return cylinders; }
            set
            {
                if ( Validation.IsIntegerInRange(value, 2, 8))
                {
                    cylinders = value;
                }
                else
                {
                    feedback += "\nERROR: Please enter a valid # of cylinders.";
                }
                
            }
        }

        public string Year
        {
            get { return year; }
            set
            {
                if ( Validation.IsInteger(value) && Validation.IsExactLength(value, 4))
                {
                    year = value;
                }
                else
                {
                    feedback += "\nERROR: Please enter a valid year.";
                }
            }
        }

        public string Feedback
        {
            get { return feedback; }
        }

        public int CarID
        {
            get { return carID; }
            set { carID = value; }
        }

        public string addRecord()
        {
            string strResults = "Connected Successfully";

            // Make a Connection
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @GetConnected();

            // Create our SQL string
            string strSQL = "INSERT INTO Cars (Make, Model, Liters, Cylinders, Year) VALUES (@Make, @Model, @Liters, @Cylinders, @Year)";

            SqlCommand comm = new SqlCommand();

            comm.CommandText = strSQL;
            comm.Connection = conn;

            // Fill parameters
            comm.Parameters.AddWithValue("@Make", Make);
            comm.Parameters.AddWithValue("@Model", Model);
            comm.Parameters.AddWithValue("@Liters", Liters);
            comm.Parameters.AddWithValue("@Cylinders", Cylinders);
            comm.Parameters.AddWithValue("@Year", Year);

            try
            {
                conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                strResults = $"Sucess: Inserted {intRecs} records.";
                conn.Close();
            }
            catch (Exception err)
            {
                strResults = "ERROR:" + err.Message;
            }
            finally
            {
                // This code runs no matter whether we have an error or not
            }
            return strResults;
        }

        public DataSet SearchCars(String strMake, String strModel)
        {
            //Create a dataset to return filled
            DataSet ds = new DataSet();


            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();


            //Write a Select Statement to perform Search
            String strSQL = "SELECT CarID, Make, Model, Liters, Cylinders, Year FROM Cars WHERE 0=0";

            //If the Make/Model is filled in include it as search criteria
            if (strMake.Length > 0)
            {
                strSQL += " AND Make LIKE @Make";
                comm.Parameters.AddWithValue("@Make", "%" + strMake + "%");
            }
            if (strModel.Length > 0)
            {
                strSQL += " AND Model LIKE @Model";
                comm.Parameters.AddWithValue("@Model", "%" + strModel + "%");
            }


            //Create DB tools and Configure
            SqlConnection conn = new SqlConnection();
            //Create the who, what where of the DB
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;

            //Fill in basic info to command object
            comm.Connection = conn;     //tell the commander what connection to use
            comm.CommandText = strSQL;  //tell the command what to say

            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;    //commander needs a translator(dataAdapter) to speak with datasets



            //Get Data
            conn.Open();                //Open the connection (pick up the phone)
            da.Fill(ds, "Cars_Temp");     //Fill the dataset with results from database and call it "Cars_Temp"
            conn.Close();               //Close the connection (hangs up phone)

            //Return the data
            return ds;
        }

        public SqlDataReader FindOneCar(int intCarID)
        {
            //Create and Initialize the DB Tools we need
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //My Connection String
            string strConn = @GetConnected();

            //My SQL command string to pull up one car's data
            string sqlString =
           "SELECT * FROM Cars WHERE CarID = @CarID;";

            //Tell the connection object the who, what, where, how
            conn.ConnectionString = strConn;

            //Give the command object info it needs
            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@CarID", intCarID);

            //Open the DataBase Connection and Yell our SQL Command
            conn.Open();

            //Return some form of feedback
            return comm.ExecuteReader();   //Return the dataset to be used by others (the calling form)
        }

        public string DeleteOneCar(int intCarID)
        {
            Int32 intRecords = 0;
            string strResult = "";

            //Create and Initialize the DB Tools we need
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //My Connection String
            string strConn = @GetConnected();

            //My SQL command string to pull up one Person's data
            string sqlString =
           "DELETE FROM Cars WHERE CarID = @CarID;";

            //Tell the connection object the who, what, where, how
            conn.ConnectionString = strConn;

            //Give the command object info it needs
            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@CarID", intCarID);

            try
            {
                //Open the connection
                conn.Open();

                //Run the Delete and store the number of records effected
                intRecords = comm.ExecuteNonQuery();
                strResult = intRecords.ToString() + " Records Deleted.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;                //Set feedback to state there was an error & error info
            }
            finally
            {
                //close the connection
                conn.Close();
            }

            return strResult;
        }

        public string UpdateARecord()
        {
            Int32 intRecords = 0;
            string strResult = "";

            // Create our SQL string
            string strSQL = "UPDATE Cars SET Make = @Make, Model = @Model, Liters = @Liters, Cylinders = @Cylinders, Year = @Year WHERE CarID = @CarID";


            // Create a connection to DB
            SqlConnection conn = new SqlConnection();
            //Create the who, what where of the DB
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;

            // Bark out our command
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;  //Commander knows what to say
            comm.Connection = conn;     //Where's the phone?  Here it is


            // Fill parameters
            comm.Parameters.AddWithValue("@Make", Make);
            comm.Parameters.AddWithValue("@Model", Model);
            comm.Parameters.AddWithValue("@Liters", Liters);
            comm.Parameters.AddWithValue("@Cylinders", Cylinders);
            comm.Parameters.AddWithValue("@Year", Year);
            comm.Parameters.AddWithValue("@CarID", CarID);

            try
            {
                //Open the connection
                conn.Open();

                //Run the Update and store the number of records effected
                intRecords = comm.ExecuteNonQuery();
                strResult = intRecords.ToString() + " Records Updated.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;                //Set feedback to state there was an error & error info
            }
            finally
            {
                //close the connection
                conn.Close();
            }

            return strResult;

        }

        // Utility function so that one string controls all SQL Server Login info
        private string GetConnected()
        {
            return @"Server = sql.neit.edu\studentsqlserver,4500; Database = se245_dcerreto; User Id = se245_dcerreto; Password = 008005661;";
        }

        // Constructor
        public Cars()
        {
            make = "";
            model = "";
            liters = "";
            cylinders = "";

            feedback = "";
        }

    }
}
